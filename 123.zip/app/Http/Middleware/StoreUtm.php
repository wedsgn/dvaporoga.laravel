<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class StoreUtm
{
    private array $keys = [
        'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term',
        'cm_id',
    ];

    public function handle(Request $request, Closure $next)
    {
        // Берём UTM из query
        $incoming = $request->only($this->keys);
        $incoming = array_filter($incoming, static fn ($v) => $v !== null && $v !== '');

        // ✅ ВАЖНО: если есть метки — ставим cookie ДО $next()
        // Тогда AddQueuedCookiesToResponse приклеит её, а EncryptCookies успеет ЗАШИФРОВАТЬ.
        if (!empty($incoming)) {
            $value = json_encode($incoming, JSON_UNESCAPED_UNICODE);

            cookie()->queue(cookie(
                'utm_payload',
                $value,
                60 * 24 * 30, // 30 дней
                '/',          // path
                null,         // domain
                $request->isSecure(), // secure (https=true)
                false,        // httpOnly
                false,        // raw
                'Lax'         // samesite
            ));

            \Log::info('StoreUtm: queued (before next)', [
                'url' => $request->fullUrl(),
                'incoming' => $incoming,
            ]);
        }

        return $next($request);
    }
}
