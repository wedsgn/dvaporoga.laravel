<?php

use App\Http\Middleware\RebuildYandexFeedIfDirty;
use App\Http\Middleware\StoreUtm;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
  ->withRouting(
    web: __DIR__ . '/../routes/web.php',
    commands: __DIR__ . '/../routes/console.php',
    health: '/up',
  )
  ->withMiddleware(function (Middleware $middleware) {
        $middleware->web(prepend: [
        StoreUtm::class,
    ]);
    $middleware->append(RebuildYandexFeedIfDirty::class);
  })
  ->withExceptions(function (Exceptions $exceptions) {
    //
  })->create();
