<div id="cookie-banner" class="cookie-banner">
    <div class="cookie-banner__container">
        <span class="cookie-banner__text">
            Мы используем файлы cookies для улучшения работы сайта.
            Оставаясь на нашем сайте, вы соглашаетесь с условиями использования файлов cookies.
        </span>

        <button id="cookie-accept" class="cookie-banner__button">
            Принять
        </button>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const banner = document.getElementById('cookie-banner');
    const button = document.getElementById('cookie-accept');

    if (!banner || !button) return;

    const cookieAccepted = localStorage.getItem('cookieAccepted');

    if (cookieAccepted) {
        banner.style.display = 'none';
    }

    button.addEventListener('click', function () {
        localStorage.setItem('cookieAccepted', 'true');
        banner.style.display = 'none';
    });

});
</script>
