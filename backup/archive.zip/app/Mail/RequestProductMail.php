<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class RequestProductMail extends Mailable
{
  use Queueable, SerializesModels;

  public $details;

  /**
   * Create a new message instance.
   *
   * @param  array  $details
   * @return void
   */
  public function __construct(array $details)
  {
      $this->details = $details;
  }

  /**
   * Get the message envelope.
   */
  public function envelope(): Envelope
  {
      return new Envelope(
          subject: $this->details['subject'],
      );
  }

  /**
   * Build the message.
   */
  public function build(): self
  {
      return $this->view('emails.request_products_email')
          ->with([
              'subject' => $this->details['subject'],
              'name' => $this->details['name'],
              'phone' => $this->details['phone'],
              'products' => $this->details['products'],
              'car' => $this->details['car'],
              'form' => $this->details['form']
          ]);
  }
}
