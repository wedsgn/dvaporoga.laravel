<footer class="footer section">
    <div class="container">
        <div class="footer-main">
            <div class="footer-main__grid">
                <div class="footer-main__brand">
                    <a href="{{ route('home') }}" class="footer-logo">
                        <img src="{{ asset('images/footerlogo.svg') }}" alt="2POROGA">
                    </a>

                    <div class="footer-main__descr">
                        Ремонтные арки и пороги для всех автомобилей
                    </div>

                    <div class="footer-main__company">
                        {{ $main_info->company_details }}
                    </div>
                </div>

                <div class="footer-main__menu">
                    <div class="footer-main__title">Информация</div>

                    <nav class="footer-main__nav">
                        <a href="{{ route('catalog') }}" class="footer__nav-link">Каталог</a>
                        <a href="{{ route('home') }}#features" class="footer__nav-link">Наши преимущества</a>
                        <a href="{{ route('home') }}#examples" class="footer__nav-link">Наши работы</a>
                        <a href="{{ route('home') }}#about" class="footer__nav-link">О нас</a>
                        <a href="{{ route('home') }}#delivery" class="footer__nav-link">Доставка и оплата</a>
                        <a href="{{ route('home') }}#partnership" class="footer__nav-link">Сотрудничество</a>
                    </nav>
                </div>

                <div class="footer-main__docs">
                    <div class="footer-main__title">Документы</div>

                    <div class="footer-main__docs-list">
                        <a href="{{ asset('docs/ОФЕРТА.docx') }}" target="_blank" rel="noopener noreferrer" class="footer__nav-link">
                            Договор оферты
                        </a>

                        <a href="{{ asset('docs/ПОЛИТИКА КОНФИДЕНЦИАЛЬНОСТИ.docx') }}" target="_blank" rel="noopener noreferrer" class="footer__nav-link">
                            Политика конфиденциальности
                        </a>

                        <a href="{{ asset('docs/СОГЛАСИЕ НА ОБРАБОТКУ ПЕРСОНАЛЬНЫХ ДАННЫХ.docx') }}" target="_blank" rel="noopener noreferrer" class="footer__nav-link">
                            Согласие на обработку персональных данных
                        </a>

                        <a href="{{ asset('docs/СОГЛАСИЕ НА ПОЛУЧЕНИЕ ИНФОРМАЦИОННЫХ РАССЫЛОК.docx') }}" target="_blank" rel="noopener noreferrer" class="footer__nav-link">
                            Согласие на получение информационной рассылки
                        </a>
                    </div>
                </div>

                <div class="footer-main__contacts">
                    <div class="footer-main__title">Контакты для связи</div>

                    <a href="tel:{{ $main_info->phone }}" class="footer-main__phone">
                        {{ $main_info->phone }}
                    </a>

                    <button type="button" class="btn btn--primary footer-main__callback" data-micromodal-trigger="modal-1">
                        Заказать звонок
                    </button>

                    <div class="footer-socials">
                        @if (!empty($main_info->whats_app))
                            <a href="{{ $main_info->whats_app }}" target="_blank" class="footer-social" rel="noopener noreferrer">
                                <img src="{{ asset('images/socials/wa.svg') }}" alt="WhatsApp">
                            </a>
                        @endif

                        @if (!empty($main_info->telegram))
                            <a href="{{ $main_info->telegram }}" target="_blank" class="footer-social" rel="noopener noreferrer">
                                <img src="{{ asset('images/socials/tg.svg') }}" alt="Telegram">
                            </a>
                        @endif

                        @if (!empty($main_info->vk))
                            <a href="{{ $main_info->vk }}" target="_blank" class="footer-social" rel="noopener noreferrer">
                                <img src="{{ asset('images/socials/vk.svg') }}" alt="VK">
                            </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
