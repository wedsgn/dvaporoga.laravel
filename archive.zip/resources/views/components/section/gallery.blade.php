@props(['block' => null])

@php
    $images = $block?->images ?? [];
    $title = $block?->title ?: 'В ассортименте запчасти на 3000 моделей авто';
@endphp

@if (!empty($images))
<section class="gallery-section section">
    <div class="container">
        <h2 class="h2">{{ $title }}</h2>

        <div class="gallery-slider-wrap">
            <div class="swiper gallery-swiper">
                <div class="swiper-wrapper">
                    @foreach ($images as $item)
                        @php
                            $url = str_starts_with($item, 'uploads/')
                                ? asset('storage/' . $item)
                                : asset($item);
                        @endphp

                        <div class="swiper-slide">
                            <a href="{{ $url }}" data-fancybox="gallery" class="gallery-slide-link">
                                <img src="{{ $url }}" alt="{{ $title }}" loading="lazy">
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="swiper-pagination banners-pagination gallery-pagination"></div>

            <div class="swiper-button-prev slider-arrow slider-arrow-prev gallery-arrow-prev">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="lucide lucide-arrow-left-icon lucide-arrow-left">
                    <path d="m12 19-7-7 7-7" />
                    <path d="M19 12H5" />
                </svg>
            </div>

            <div class="swiper-button-next slider-arrow slider-arrow-next gallery-arrow-next">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="lucide lucide-arrow-right-icon lucide-arrow-right">
                    <path d="M5 12h14" />
                    <path d="m12 5 7 7-7 7" />
                </svg>
            </div>
        </div>
    </div>
</section>
@endif
