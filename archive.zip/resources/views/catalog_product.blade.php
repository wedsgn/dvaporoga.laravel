@extends('layouts.front')

@section('content')
    <main>

        {{ Breadcrumbs::render('car_generation.show', $car_make, $car_model, $car) }}

        <section class="car-single__hero-section">
            @php
                $img = null;

                if (!empty($car->image) && $car->image !== 'default') {
                    $img = asset('storage/' . $car->image);
                } elseif (!empty($car->image_mob) && $car->image_mob !== 'default') {
                    $img = asset('storage/' . $car->image_mob);
                } else {
                    $img = asset('images/cars/merc.png');
                }
            @endphp

            <div class="container">
                <div class="car-single-hero__wrap">
                    <div class="car-single-hero__info">
                        <h1 class="car-single__title">
                            КУЗОВНЫЕ ЭЛЕМЕНТЫ
                            ДЛЯ <br><span>{{ mb_strtoupper($car->title) }}</span>
                        </h1>

                        <div class="car-single-hero__image car-single-hero__image--mob">
                            <img src="{{ $img }}" alt="{{ $car->title }}">
                        </div>

                        <div class="car-single-hero__features">
                            <div class="car-single-hero__feature">Оплата при получении</div>
                            <div class="car-single-hero__feature">ХКС и Оцинковка</div>
                            <div class="car-single-hero__feature">От 0,8 до 1,5 мм</div>
                            <div class="car-single-hero__feature">Доставка по РФ</div>
                            <div class="car-single-hero__feature">Повторение оригинала</div>
                        </div>

                        <div class="car-single-hero__promo-wrap">
                            <div class="car-single-hero__promo">
                                <div class="car-single-hero__promo-item">
                                    <div class="car-single-hero__promo-item-title">
                                        ПОРОГИ
                                    </div>

                                    <div class="car-single-hero__promo-item-price-wrap">
                                        <div class="car-single-hero__promo-item-price">1 690 ₽</div>
                                        <div class="car-single-hero__promo-item-price-old">2 050 ₽</div>
                                    </div>
                                </div>
                            </div>

                            <div class="car-single-hero__promo">
                                <div class="car-single-hero__promo-item">
                                    <div class="car-single-hero__promo-item-title">
                                        АРКИ
                                    </div>

                                    <div class="car-single-hero__promo-item-price-wrap">
                                        <div class="car-single-hero__promo-item-price">1 950 ₽</div>
                                        <div class="car-single-hero__promo-item-price-old">2 250 ₽</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="car-single-hero__image car-single-hero__image--desk">
                        <img src="{{ $img }}" alt="{{ $car->title }}">
                    </div>
                </div>
            </div>
        </section>

        <section class="car-single-form-section">
            <div class="container">
                <div class="car-single-form-section__top">
                    <div class="car-single-form-section__label">
                        <img src="{{ asset('images/icons/fire.svg') }}" alt="">
                        <p>Акция</p>
                    </div>

                    <h2 class="car-single-form-section__title">Оставьте заявку</h2>
                </div>

                <p class="car-single-form-section__descr">
                    Мы подберем деталь под ваш автомобиль и ответим на все вопросы
                </p>

                <form id="car-request-form" action="{{ route('requests.car') }}" method="POST" class="car-single-form"
                    data-action="{{ route('requests.car') }}" data-ym-goal="calculator" data-ym-mode="manual">
                    @csrf

                    <input type="hidden" name="form_id" value="car-page-form">
                    <input type="hidden" name="car_id" value="{{ $car->id }}">
                    <input type="hidden" name="current_url" value="{{ request()->fullUrl() }}">

                    <input type="hidden" name="utm_source" value="{{ $utm['utm_source'] ?? '' }}">
                    <input type="hidden" name="utm_medium" value="{{ $utm['utm_medium'] ?? '' }}">
                    <input type="hidden" name="utm_campaign" value="{{ $utm['utm_campaign'] ?? '' }}">
                    <input type="hidden" name="utm_term" value="{{ $utm['utm_term'] ?? '' }}">
                    <input type="hidden" name="utm_content" value="{{ $utm['utm_content'] ?? '' }}">
                    <input type="hidden" name="cm_id" value="{{ $utm['cm_id'] ?? '' }}">

                    <div class="choose-section__form_row">
                        <div class="input-item">
                            <input class="input black" type="text" name="name" placeholder="Имя" required>
                            <div class="field-error" data-error-for="name"></div>
                        </div>

                        <div class="input-item">
                            <input class="input black" type="tel" name="phone" placeholder="+7 (___) ___ __ __"
                                required>
                            <div class="field-error" data-error-for="phone"></div>
                        </div>

                        <button type="submit" class="btn btn-black car-single-form-btn">Отправить</button>
                    </div>

                    <div class="form-policy-wrap">
                        <div class="form-policy">
                            <input type="checkbox" id="choose-check" name="policy" value="1" required>
                            <label for="choose-check">
                                Я соглашаюсь с
                                <a href="{{ url('/policy.pdf') }}" target="_blank" rel="noopener noreferrer">
                                    политикой конфиденциальности
                                </a>
                                и даю согласие на обработку персональных данных
                            </label>
                        </div>
                        <div class="field-error field-error--policy" data-error-for="policy"></div>
                    </div>
                </form>
            </div>
        </section>

        <section class="car-single-parts-section">
            <div class="container">
                <h2 class="h2">Запчасти на <span>{{ $car->title }}</span></h2>

                <div class="car-single-parts">
                    @foreach ($products as $p)
                        @php
                            $pivotPath =
                                !empty($p->pivot?->image) && $p->pivot->image !== 'default'
                                    ? ltrim($p->pivot->image, '/')
                                    : null;

                            $adminPath = !empty($p->image) && $p->image !== 'default' ? ltrim($p->image, '/') : null;

                            $fallbackPath = null;
                            foreach (['webp', 'jpg', 'jpeg', 'png'] as $ext) {
                                $pp = "products_default/{$p->slug}.{$ext}";
                                if (\Illuminate\Support\Facades\Storage::disk('public')->exists($pp)) {
                                    $fallbackPath = $pp;
                                    break;
                                }
                            }

                            $finalPath = $pivotPath ?: ($adminPath ?: $fallbackPath);
                            $imageUrl = $finalPath ? asset('storage/' . $finalPath) : asset('images/no-image.jpg');
                        @endphp

                        <x-car-single-part :id="$p->id" :image="$imageUrl" :discount_percentage="$p->discount_percentage ? '-' . $p->discount_percentage . ' %' : ''" :title="$p->title"
                            :description="$p->description ?? ''" :price="$p->price ? number_format((int) $p->price, 0, '.', ' ') . ' ₽' : ''" :priceOld="$p->price_old ? number_format((int) $p->price_old, 0, '.', ' ') . ' ₽' : ''" :link="$p->link ?? ''" :alt="$p->alt ?: $p->title"
                            request-source="car" :request-car="$car->title" />
                    @endforeach
                </div>
            </div>
        </section>

        <x-section.about-parts />
        <x-section.repair-examples :block="$repairExamplesBlock" />
        <x-section.reviews />
        <x-section.how-we-work />
        <x-section.about-company />
        <x-section.faq />
    </main>
@endsection
