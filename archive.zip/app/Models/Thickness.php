<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Thickness extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'slug'
    ];

    public function products()
    {
        return $this->belongsToMany(Product::class);
    }

    public function prices()
    {
        return $this->hasMany(Price::class);
    }
}
